<?php
require 'mojang-api.class.php';

class DcUUIDHooks {
   // Register any render callbacks with the parser
   public static function onParserFirstCallInit( Parser $parser ) {

      // Create a function hook associating the "example" magic word with renderExample()
      $parser->setFunctionHook( 'UUID', [ self::class, 'renderUUID' ] );
   }

   // Render the output of {{#example:}}.
   public static function renderUUID( Parser $parser, $param1 = '') {

      $dcuuid = MojangAPI::getUuid( $param1 );
	  // The input parameters are wikitext with templates expanded.
      // The output should be wikitext too.
      $output = "$dcuuid";

      return $output;
   }
}