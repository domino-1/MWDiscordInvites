<?php
/**
 * @license GPL-2.0-or-later
 * @author Domino
 */

$magicWords = [];

/** English
 * @author Domino
 */
$magicWords['en'] = [
   'UUID' => [ 0, 'UUID' ],
];